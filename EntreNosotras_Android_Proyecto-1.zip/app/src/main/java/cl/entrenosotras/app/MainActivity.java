package cl.entrenosotras.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.webkit.WebViewAssetLoader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/**
 * EntreNosotras v1.0 - prototipo offline basado en WebViewAssetLoader.
 * Todos los HTML/JS/CSS se sirven desde assets a un origen HTTPS local.
 * Los datos se guardan solamente dentro del WebView del teléfono.
 */
public class MainActivity extends Activity {
    private static final String ROOT = "https://appassets.androidplatform.net/assets/";
    private static final int SAVE_JSON_REQUEST = 1926;
    private WebView webView;
    private byte[] pendingJson;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(107,45,131));
        getWindow().setNavigationBarColor(Color.rgb(255,249,255));
        getWindow().getDecorView().setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
            .build();
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(255,249,255));
        webView.setVerticalScrollBarEnabled(false);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setUserAgentString(settings.getUserAgentString() + " EntreNosotrasAndroid/1.0");
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new LocalExportBridge(), "EntreNosotrasAndroid");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                // No navegar a sitios externos ni entregar el puente JS a páginas de terceros.
                return !("https".equals(uri.getScheme())
                    && "appassets.androidplatform.net".equals(uri.getHost())
                    && uri.getPath() != null && uri.getPath().startsWith("/assets/"));
            }
        });
        setContentView(webView);
        webView.loadUrl(ROOT + "index.html");
    }

    private class LocalExportBridge {
        @JavascriptInterface
        public void exportJson(String proposedName, String json) {
            if (json == null || json.length() > 2_000_000) return;
            final String filename = (proposedName == null ? "entrenosotras-datos.json" : proposedName)
                .replaceAll("[^A-Za-z0-9_.-]", "_");
            final byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
            runOnUiThread(() -> {
                try {
                    pendingJson = bytes;
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    intent.putExtra(Intent.EXTRA_TITLE, filename);
                    startActivityForResult(intent, SAVE_JSON_REQUEST);
                } catch (Exception exception) {
                    Toast.makeText(MainActivity.this, "No se pudo abrir el selector de archivos", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != SAVE_JSON_REQUEST) return;
        if (resultCode != RESULT_OK || data == null || data.getData() == null || pendingJson == null) {
            pendingJson = null;
            return;
        }
        try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
            if (out == null) throw new IllegalStateException("Sin acceso al archivo");
            out.write(pendingJson);
            Toast.makeText(this, "Copia de datos guardada", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "No se pudieron exportar los datos", Toast.LENGTH_LONG).show();
        } finally {
            pendingJson = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("EntreNosotrasAndroid");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
