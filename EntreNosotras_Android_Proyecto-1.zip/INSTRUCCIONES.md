# EntreNosotras – aplicación Android v1.0

## Estado de entrega
**Proyecto Android completo listo para compilar. NO es un archivo APK ya compilado.**
El APK se obtiene con Android Studio o, sin instalar herramientas en el PC, con GitHub Actions.

## Opción A — obtener un APK con Android Studio
1. Instala **Android Studio** en un computador con acceso a internet.
2. Extrae `EntreNosotras_Android_Proyecto.zip`.
3. En Android Studio: **Open** y selecciona la carpeta `EntreNosotras_Android`.
4. Espera la sincronización de Gradle (requiere internet la primera vez).
5. Selecciona **Build > Build Bundle(s) / APK(s) > Build APK(s)** (también se puede ejecutar `gradle :app:assembleDebug`).
6. El archivo instalable queda en `app/build/outputs/apk/debug/app-debug.apk`.
7. Pásalo a tu Huawei P60 Pro, ábrelo y acepta instalar desde esa fuente si Android lo pide.

## Opción B — crear el APK gratis usando GitHub Actions
1. Inicia sesión en GitHub y crea un repositorio privado nuevo y vacío (sin README generado).
2. Extrae el ZIP en el computador. Sube **el contenido de la carpeta** al repositorio, manteniendo las carpetas `.github` y `app` (no subas el ZIP sin extraer).
3. En GitHub entra a **Actions > Compilar APK EntreNosotras > Run workflow**. Si la compilación comenzó al subir el contenido, basta con abrir la ejecución.
4. Cuando esté completada correctamente, entra en esa ejecución, baja hasta **Artifacts** y descarga **EntreNosotras-APK-debug**.
5. Extrae el ZIP del artifact: dentro está `app-debug.apk`. Copia ese APK al Huawei e instálalo.

## Qué contiene
- WebView Android con contenido local integrado, sin solicitar permiso de Internet.
- Pantallas de agenda, metas, red de apoyo *local*, bienestar, futuro y directorio *de demostración*.
- Almacenamiento local en el teléfono. Los datos pueden perderse al desinstalar o borrar almacenamiento.
- Exportación de registros JSON a través del selector de documentos nativo de Android.
- Ícono EntreNosotras, nombre, pantalla completa sin barra de acción.

## Advertencias
- Esta es una APK **de prueba**, no un servicio de salud ni una red social pública. No incluye cuentas, backend, profesionales validados, chats ni reservas reales.
- La aplicación guarda notas potencialmente sensibles en almacenamiento local no cifrado a nivel de la aplicación. No ingreses información médica sensible ni datos de terceras personas para las pruebas.
- El archivo **debug APK** está firmado automáticamente con clave de desarrollo; sirve para instalar y probar, NO para publicar en una tienda.
- Para versiones posteriores, firma de distribución, copias de seguridad, autenticación, permisos y controles de privacidad deberán diseñarse antes del uso público.

## Estructura
```
app/src/main/assets/                  Prototipo completo offline
app/src/main/java/cl/entrenosotras/app/MainActivity.java
app/src/main/AndroidManifest.xml       Configuración Android
app/src/main/res/                       Ícono y tema
.github/workflows/compilar-apk.yml    Compilación automática
```

## Configuración técnica
Android Gradle Plugin 8.13.2; Gradle 8.13; Java 17; compileSdk 35; minSdk 26; targetSdk 34; AndroidX WebKit 1.13.0. 
Application ID: `cl.entrenosotras.app`.
